
import pydoc
if __name__ == '__main__':
    pydoc.cli()
